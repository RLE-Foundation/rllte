from .drqv2 import DrQv2Agent as ContinuousLearner
from .ppg import PPGAgent as DiscreteLearner
#


## BaseAugmentation
[source](https://github.com/BellmanProject/Hsuanwu/blob/main/hsuanwu/xplore/augmentation/base.py/#L6)
```python 

```


---
Base class of augmentation.



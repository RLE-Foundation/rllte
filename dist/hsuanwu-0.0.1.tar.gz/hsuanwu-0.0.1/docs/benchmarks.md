# Benchmarks

Find all the benchmark results in [https://benchmark.hsuanwu.dev/](https://benchmark.hsuanwu.dev/).